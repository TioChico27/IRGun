var searchData=
[
  ['directprocessor_17',['DirectProcessor',['../classace__utils_1_1cli_1_1DirectProcessor.html',1,'ace_utils::cli::DirectProcessor'],['../classace__utils_1_1cli_1_1DirectProcessor.html#a4c4f50a18c1c95017649dee77ad32193',1,'ace_utils::cli::DirectProcessor::DirectProcessor()']]],
  ['directprocessormanager_18',['DirectProcessorManager',['../classace__utils_1_1cli_1_1DirectProcessorManager.html',1,'ace_utils::cli::DirectProcessorManager&lt; BUF_SIZE, ARGV_SIZE &gt;'],['../classace__utils_1_1cli_1_1DirectProcessorManager.html#af030774dd3baa22d3a1971639337f336',1,'ace_utils::cli::DirectProcessorManager::DirectProcessorManager()']]]
];
