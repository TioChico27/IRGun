var searchData=
[
  ['parentgroup_38',['parentGroup',['../structace__utils_1_1mode__group_1_1ModeGroup.html#a8e8e2d3b47f11a516d70d2664db9bcde',1,'ace_utils::mode_group::ModeGroup']]],
  ['process_39',['process',['../classace__utils_1_1cli_1_1DirectProcessor.html#a49890c21a2ea919f1b9d182c3618631a',1,'ace_utils::cli::DirectProcessor::process()'],['../classace__utils_1_1cli_1_1DirectProcessorManager.html#a8460d968f80edc74a4612b1737583b54',1,'ace_utils::cli::DirectProcessorManager::process()']]]
];
